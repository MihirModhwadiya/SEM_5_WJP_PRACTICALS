create
    definer = root@localhost procedure CalculateArea(IN radius float, OUT circleArea float)
BEGIN
    DECLARE pi FLOAT(20,2);
    SET pi = 3.14;
    SET circleArea = pi * radius * radius;
END;

