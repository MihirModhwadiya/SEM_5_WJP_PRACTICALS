create
    definer = root@localhost procedure `add`(INOUT firstname varchar(30), INOUT middlename varchar(30),
                                             INOUT lastname varchar(30))
BEGIN
INSERT INTO name VALUES (firstname , middlename , lastname);
END;

