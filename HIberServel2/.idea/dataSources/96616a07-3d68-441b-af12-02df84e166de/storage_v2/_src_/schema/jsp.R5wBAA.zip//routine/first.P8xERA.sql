create
    definer = root@localhost procedure first(IN a varchar(255), IN b varchar(255), IN c varchar(255))
BEGIN
	INSERT INTO name VALUES(a,b,c);
END;

