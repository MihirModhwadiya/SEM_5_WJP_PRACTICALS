create
    definer = root@localhost procedure store(IN name varchar(255), OUT storename varchar(255))
BEGIN
	SELECT firstname INTO storename WHERE firstname = name ;
END;

